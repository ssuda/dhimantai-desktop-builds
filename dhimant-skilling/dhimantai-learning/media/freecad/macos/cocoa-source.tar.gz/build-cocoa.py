"""Build one Cocoa plugin slice from the accompanying Qt source on macOS."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--arch', choices=['arm64', 'x86_64'], required=True)
parser.add_argument('--qt', type=Path, required=True, help='Extracted conda-forge qt6-main for the target architecture')
parser.add_argument('--tools', type=Path, required=True, help='Directory containing native Qt 6.11.2 moc and rcc')
parser.add_argument('--headers', type=Path, required=True, help='Include root with vulkan/ and MoltenVK/')
parser.add_argument('--output', type=Path, required=True, help='Empty directory for this build')
args = parser.parse_args()
src = Path(__file__).resolve().parent / 'cocoa'
out = args.output.resolve()
out.mkdir(parents=True, exist_ok=True)
if any(out.iterdir()):
    parser.error('--output must be empty')
qt = args.qt.resolve()
tools = args.tools.resolve()
include = qt / 'include/qt6'
directories = [src, out, include, args.headers.resolve()]
for module in ('QtCore', 'QtGui'):
    directories += [include/module, include/module/'6.11.2', include/module/'6.11.2'/module]
includes = ['-I' + str(path) for path in directories]
sdk = subprocess.check_output(['xcrun', '--show-sdk-path'], text=True).strip()
target = ['-arch', args.arch, '-isysroot', sdk, '-mmacosx-version-min=' + ('11.0' if args.arch == 'arm64' else '10.15')]

def run(command):
    subprocess.run(command, check=True)

sources = sorted(src.glob('*.mm'))
implementations = ''.join(p.read_text() for p in sources)
sources = [p for p in sources if not p.stem.startswith('qnsview_')]
for p in sources:
    if '#include "' + p.stem + '.moc"' in p.read_text():
        run([tools/'moc', *includes, p, '-o', out/(p.stem + '.moc')])
standalone = []
for header in sorted(src.glob('*.h')):
    if 'Q_OBJECT' in header.read_text():
        name = 'moc_' + header.stem + '.cpp'
        run([tools/'moc', *includes, header, '-o', out/name])
        if name not in implementations:
            standalone.append('#include "' + name + '"')
moc = out/'moc_objects.mm'
moc.write_text('\n'.join(standalone) + '\n')
qrc = out/'cursors.qrc'
from xml.etree import ElementTree as ET
resources = ET.Element('RCC')
group = ET.SubElement(resources, 'qresource', prefix='/qt-project.org/mac/cursors')
for png in sorted((src/'images').glob('*.png')):
    ET.SubElement(group, 'file', alias='images/'+png.name).text = str(png)
ET.ElementTree(resources).write(qrc, encoding='utf-8')
run([tools/'rcc', '-name', 'qcocoaresources', qrc, '-o', out/'qrc.cpp'])
sources += [src/'qcocoasessionmanager.cpp', out/'qrc.cpp', moc]

def compile_source(source):
    obj = out/(source.stem + '.o')
    run(['/usr/bin/clang++', '-std=c++20', '-O2', '-fPIC', '-fvisibility=hidden', '-fvisibility-inlines-hidden',
         *target, '-DQT_NO_DEBUG', '-DQT_PLUGIN', '-DQT_BUILDING_QT', '-DQT_USE_QSTRINGBUILDER',
         '-Wno-deprecated-declarations', '-Wno-unguarded-availability-new', *includes, '-c', source, '-o', obj])
    return obj

with ThreadPoolExecutor(max_workers=5) as workers:
    objects = list(workers.map(compile_source, sources))
frameworks = ('Foundation AppKit Carbon CoreServices CoreVideo IOKit IOSurface Metal QuartzCore UniformTypeIdentifiers '
              'OpenGL ApplicationServices ColorSync CoreFoundation CoreGraphics CoreText').split()
flags = [flag for name in frameworks for flag in ['-framework', name]]
run(['/usr/bin/clang++', '-bundle', *target, *objects, qt/'lib/libQt6Gui.6.dylib', qt/'lib/libQt6Core.6.dylib',
     *flags, '-o', out/'libqcocoa.dylib'])
